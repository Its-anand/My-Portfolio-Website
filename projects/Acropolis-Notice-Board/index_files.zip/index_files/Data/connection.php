<?php
$server = "localhost";
$username = "acroboar_admin";
$password = "Mm95z6@MmxuTJgW";
$db = "acroboar_bd";
$con = new mysqli($server, $username, $password, $db);
mysqli_set_charset($con, "utf8");
// if ($con->connect_error) {
//     die("Connection failed: " . $con->connect_error);
// }
// echo "Connected successfully";
?>
